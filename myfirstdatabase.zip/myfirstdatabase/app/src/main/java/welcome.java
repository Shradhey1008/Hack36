import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.example.myfirstdatabase.R;

//public class welcome extends AppCompatActivity {
   // private Button button;

    //@Override
    //protected void onCreate(Bundle savedInstanceState){
      //  super.onCreate(savedInstanceState);
        //setContentView(R.layout.welcome);

        //button=(Button)findViewById(R.id.button);

    //}
//}
