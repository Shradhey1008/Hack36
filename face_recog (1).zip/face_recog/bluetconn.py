from bluetool import Bluetooth
from bluetool import BluetoothServer

bluetooth = Bluetooth()
bluetooth.scan()
devices = bluetooth.get_available_devices()
print(devices)