from firebase import firebase

firebase = firebase.FirebaseApplication("https://myfirstdatabase-3cd86.firebaseio.com/")

result = firebase.get('/ID', None)

print(result)