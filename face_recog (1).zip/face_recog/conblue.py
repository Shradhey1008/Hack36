import bluetooth

nearby_devices = bluetooth.discover_devices(lookup_names=True)
print("Found {} devices.".format(len(nearby_devices)))

for addr, name in nearby_devices:
   print("  {} - {}".format(addr, name))
#
#
# def connect ():
#     bd_addr = '24:79:F3:C1:B3:BE'
#     port = 8080
#     sock=bluetooth.BluetoothSocket(bluetooth.RFCOMM)
#     sock.connect((bd_addr, port))
#     sock.send("hello!!")
#     sock.close()
#
# connect()



# import bluetooth
#
# name="bt_server"
# target_name="OPPO F11 PRO"
# uuid="24:79:F3:C1:B3:BE"
# port = 8080
#
# def runServer():
#     serverSocket=bluetooth.BluetoothSocket(bluetooth.RFCOMM )
#     port=bluetooth.PORT_ANY
#     serverSocket.bind(("",port))
#     print("Listening for connections on port: ", port)
#     serverSocket.listen(1)
#     port=serverSocket.getsockname()[1]
#     inputSocket, address=serverSocket.accept()
#     print("Got connection with" , address)
#     data=inputSocket.recv("1024")
#     print("received [%s] \n " % data )
#     inputSocket.close()
#     serverSocket.close()
#
# runServer()
#
#
# import bluetooth

# target_name = 'OPPO F11 Pro'
# target_address = None
#
# nearby_devices = bluetooth.discover_devices()
#
# for bdaddr in nearby_devices:
#     if target_name == bluetooth.lookup_name(bdaddr):
#         target_address = bdaddr
#         break
#
# if target_address is not None:
#     print("found target bluetooth device with address ", target_address)
# else:
#     print("could not find target bluetooth device nearby")


import bluetooth

server_sock=bluetooth.BluetoothSocket( bluetooth.RFCOMM )

port = 1
server_sock.bind(("",port))
server_sock.listen(1)

client_sock,address = server_sock.accept()
print("Accepted connection from ",address)

data = client_sock.recv(1024)
print("received [%s]" % data)

client_sock.close()
server_sock.close()